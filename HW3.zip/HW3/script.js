// Select all piano key elements
const pianoKeys = document.querySelectorAll('.piano-key');

// Map keyboard keys to musical notes
const keyMap = {
    'a': 'A4',
    's': 'B4',
    'd': 'C4',
    'f': 'D4',
    'g': 'E4',
    'h': 'F4',
    'j': 'G4'
};

// Store audio objects for each note
const audioFiles = {};

// Load audio files for piano keys
function initAudioFiles() {
    pianoKeys.forEach(key => {
        const note = key.dataset.note;
        const soundPath = key.dataset.sound;
        
        audioFiles[note] = new Audio(soundPath);
        audioFiles[note].preload = 'auto';
        audioFiles[note].volume = 0.7;
        
        audioFiles[note].addEventListener('error', () => {
            console.warn(`Failed to load ${soundPath}, fallback to generated tone for ${note}`);
            audioFiles[note] = null;
        });
    });
}

// Web Audio API context for fallback tones
let audioContext;

function initGeneratedAudio() {
    if (!audioContext) {
        audioContext = new (window.AudioContext || window.webkitAudioContext)();
    }
}

// Frequencies for generated tones (Hz)
const noteFrequencies = {
    'A4': 440.00,
    'B4': 493.88,
    'C4': 261.63,
    'D4': 293.66,
    'E4': 329.63,
    'F4': 349.23,
    'G4': 392.00
};

// Play a generated sine tone for fallback
function playGeneratedTone(frequency, duration = 0.5) {
    initGeneratedAudio();
    
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    
    oscillator.frequency.setValueAtTime(frequency, audioContext.currentTime);
    oscillator.type = 'sine';
    
    gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + duration);
    
    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + duration);
}

// Play audio for a given note, fallback to generated tone if necessary
function playSound(note) {
    const audio = audioFiles[note];
    
    if (audio && audio.readyState >= 2) {
        audio.currentTime = 0;
        audio.play().catch(() => {
            playGeneratedTone(noteFrequencies[note]);
        });
    } else {
        playGeneratedTone(noteFrequencies[note]);
    }
}

// Activate visual and audio feedback for a piano key
function activateKey(note) {
    const keyElement = document.querySelector(`[data-note="${note}"]`);
    if (keyElement) {
        keyElement.classList.add('active');
        playSound(note);
        setTimeout(() => {
            keyElement.classList.remove('active');
        }, 300);
    }
}

// Add temporary "pressed" style to a piano key
function pressKey(note) {
    const keyElement = document.querySelector(`[data-note="${note}"]`);
    if (keyElement) {
        keyElement.classList.add('pressed');
        setTimeout(() => {
            keyElement.classList.remove('pressed');
        }, 150);
    }
}

// Mouse click event listeners for piano keys
pianoKeys.forEach(key => {
    key.addEventListener('click', () => {
        const note = key.dataset.note;
        pressKey(note);
        activateKey(note);
    });
    
    key.addEventListener('mouseenter', () => {
        key.style.transform = 'translateY(-3px) scale(1.02)';
    });
    
    key.addEventListener('mouseleave', () => {
        if (!key.classList.contains('active')) {
            key.style.transform = '';
        }
    });
});

// Track pressed keys to prevent repeat triggering
let keysPressed = new Set();

document.addEventListener('keydown', (event) => {
    const key = event.key.toLowerCase();
    if (keyMap[key] && !keysPressed.has(key)) {
        keysPressed.add(key);
        event.preventDefault();
        const note = keyMap[key];
        pressKey(note);
        activateKey(note);
    }
});

document.addEventListener('keyup', (event) => {
    const key = event.key.toLowerCase();
    if (keyMap[key]) {
        keysPressed.delete(key);
    }
});

// Initialize audio files and setup audio context on user interaction
document.addEventListener('DOMContentLoaded', () => {
    initAudioFiles();
    
    document.addEventListener('click', initGeneratedAudio, { once: true });
    document.addEventListener('keydown', initGeneratedAudio, { once: true });
});

// Optional debug function to check audio loading status
function checkAudioStatus() {
    Object.keys(audioFiles).forEach(note => {
        const audio = audioFiles[note];
        if (audio) {
            console.log(`${note}: readyState=${audio.readyState}, can play=${audio.readyState >= 2}`);
        } else {
            console.log(`${note}: using generated tone fallback`);
        }
    });
}

// Intro audio playback on page load with autoplay handling
function playIntroAudio() {
    const introAudio = new Audio('sounds/intro.ogg');
    introAudio.volume = 0.5;

    const playPromise = introAudio.play();

    if (playPromise !== undefined) {
        playPromise.then(() => {
            console.log('Intro audio started');
        }).catch(() => {
            const resumeAudio = () => {
                introAudio.play();
                window.removeEventListener('click', resumeAudio);
                window.removeEventListener('keydown', resumeAudio);
            };
            window.addEventListener('click', resumeAudio);
            window.addEventListener('keydown', resumeAudio);
        });
    }
}

window.addEventListener('load', playIntroAudio);
